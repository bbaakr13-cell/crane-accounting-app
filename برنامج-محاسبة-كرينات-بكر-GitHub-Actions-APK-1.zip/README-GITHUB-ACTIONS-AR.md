# بناء APK من الجوال عبر GitHub Actions

هذه النسخة مجهزة بحيث يبني GitHub ملف APK تلقائياً بدون كمبيوتر.

## الخطوات من الجوال

1. أنشئ مستودع GitHub جديداً، مثلاً:
   `bakr-crane-accounting-android`

2. ارفع **محتويات هذا المشروع** إلى المستودع.
   يجب أن يظهر في الجذر:
   - `.github`
   - `android`
   - `web`
   - `README-ANDROID.md`

3. افتح تبويب **Actions** في GitHub.

4. اختر:
   **Build Android APK**

5. اضغط:
   **Run workflow**

6. انتظر حتى تصبح العلامة خضراء.

7. افتح تشغيل الـ workflow المكتمل.

8. انزل إلى قسم:
   **Artifacts**

9. نزّل:
   **Bakr-Crane-Accounting-APK**

10. فك الضغط، وستجد:
    `app-debug.apk`

11. افتح ملف APK على هاتف Android وثبته.
    قد تحتاج تفعيل:
    **السماح بالتثبيت من هذا المصدر**.

## ملاحظة
هذه النسخة Debug مناسبة للتجربة والتثبيت المباشر.
إذا أردت لاحقاً نسخة Release موقعة للنشر في Google Play، نضيف توقيع Keystore منفصل.
