# برنامج محاسبة كرينات بكر — مشروع Android

هذا الملف يحتوي على:
- `web/` — مشروع React/Vite الأصلي بعد تهيئته للعمل داخل تطبيق Android.
- `android/` — مشروع Android Studio Native WebView.
- `prepare_android.bat` — تجهيز سريع على Windows.
- `prepare_android.sh` — تجهيز على macOS/Linux.

## أول مرة فقط

### على Windows
شغّل:
`prepare_android.bat`

### أو من Terminal
```bash
cd web
npm install
npm run android:prepare
```

بعدها افتح مجلد `android` باستخدام Android Studio.

## إخراج APK
في Android Studio:
**Build > Build App Bundle(s) / APK(s) > Build APK(s)**

ملف Debug يكون عادة داخل:
`android/app/build/outputs/apk/debug/app-debug.apk`

## معلومات التطبيق
- الاسم: برنامج محاسبة كرينات بكر
- Package: `com.bakr.craneaccounting`
- رقم الجوال داخل المشروع: 0558995962
- الاتجاه: عربي RTL
- الصور من معرض الهاتف مدعومة في WebView.
- الإنترنت مفعّل للاتصال بـ Supabase.

## ملاحظة
لأن بيئة التجهيز الحالية لا تحتوي على Android SDK/Gradle الكامل ولا يمكنها تنزيل حزم npm من الإنترنت، تم تجهيز المشروع ليُبنى مباشرة على جهاز فيه Android Studio وNode.js. بعد تشغيل `prepare_android` مرة واحدة، يصبح مجلد Android جاهزًا لبناء APK.
