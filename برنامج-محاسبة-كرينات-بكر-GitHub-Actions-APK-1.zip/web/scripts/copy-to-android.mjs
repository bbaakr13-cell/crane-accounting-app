import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const dist = path.join(root, 'dist');
const target = path.resolve(root, '../android/app/src/main/assets/www');

if (!fs.existsSync(dist)) {
  console.error('dist folder not found. Run npm run build first.');
  process.exit(1);
}
fs.rmSync(target, { recursive: true, force: true });
fs.mkdirSync(target, { recursive: true });
fs.cpSync(dist, target, { recursive: true });
console.log('Android web assets updated:', target);
