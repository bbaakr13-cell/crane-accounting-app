/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"IBM Plex Sans Arabic"', '"Tajawal"', 'system-ui', 'sans-serif'],
        display: ['"Tajawal"', '"IBM Plex Sans Arabic"', 'system-ui', 'sans-serif'],
      },
      colors: {
        ink: {
          950: '#070b15',
          900: '#0a0f1c',
          850: '#0e1424',
          800: '#121a2e',
          700: '#1a2440',
          600: '#243056',
          500: '#33406b',
        },
        gold: {
          50: '#fff9ed',
          100: '#ffefc9',
          200: '#ffdd95',
          300: '#ffc75c',
          400: '#ffb43a',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
          800: '#92400e',
          900: '#78350f',
        },
        income: {
          DEFAULT: '#22c55e',
          dark: '#16a34a',
          soft: '#0f2a1c',
        },
        expense: {
          DEFAULT: '#ef4444',
          dark: '#dc2626',
          soft: '#2a1414',
        },
        profit: {
          DEFAULT: '#3b82f6',
          dark: '#2563eb',
          soft: '#0f1c2e',
        },
        receivable: {
          DEFAULT: '#f97316',
          dark: '#ea580c',
          soft: '#2a1a0f',
        },
      },
      boxShadow: {
        card: '0 4px 24px -8px rgba(0, 0, 0, 0.6), 0 1px 2px rgba(0, 0, 0, 0.3)',
        glow: '0 0 24px -4px rgba(245, 158, 11, 0.35)',
        'glow-gold': '0 8px 32px -8px rgba(245, 158, 11, 0.45)',
      },
      borderRadius: {
        '2xl': '1.25rem',
        '3xl': '1.75rem',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '200% 0' },
          '100%': { backgroundPosition: '-200% 0' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.5s ease-out both',
        'scale-in': 'scale-in 0.4s ease-out both',
        'slide-up': 'slide-up 0.5s ease-out both',
        shimmer: 'shimmer 2.5s linear infinite',
      },
    },
  },
  plugins: [],
};
