/*
# Create equipment table (single-tenant, no auth)

1. New Tables
- `equipment`
  - `id` (uuid, primary key, auto-generated)
  - `name` (text, not null) — Arabic name of the equipment
  - `type` (text, not null) — equipment type: 'crane', 'boom_truck', 'other'
  - `capacity` (text) — load capacity in tons, free text
  - `plate_number` (text) — optional plate number
  - `status` (text, not null, default 'active') — 'active', 'maintenance', 'idle'
  - `notes` (text) — optional notes
  - `image_data` (text) — base64-encoded image data URL for the equipment photo
  - `hourly_rate` (numeric, default 0)
  - `daily_rate` (numeric, default 0)
  - `total_income` (numeric, default 0)
  - `total_expenses` (numeric, default 0)
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

2. Security
- Enable RLS on `equipment`.
- Allow anon + authenticated full CRUD because this is a single-tenant app with no sign-in screen.
- All policies use `USING (true)` / `WITH CHECK (true)` because the data is intentionally shared/public.

3. Important Notes
- This table stores equipment images as base64 data URLs in the `image_data` text column.
- The 7 existing equipment items will be seeded via a separate data migration.
- `updated_at` is maintained by a trigger on UPDATE.
*/

CREATE TABLE IF NOT EXISTS equipment (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL DEFAULT 'other',
  capacity text DEFAULT '',
  plate_number text DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  notes text DEFAULT '',
  image_data text DEFAULT '',
  hourly_rate numeric DEFAULT 0,
  daily_rate numeric DEFAULT 0,
  total_income numeric DEFAULT 0,
  total_expenses numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE equipment ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_equipment" ON equipment;
CREATE POLICY "anon_select_equipment" ON equipment FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_equipment" ON equipment;
CREATE POLICY "anon_insert_equipment" ON equipment FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_equipment" ON equipment;
CREATE POLICY "anon_update_equipment" ON equipment FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_equipment" ON equipment;
CREATE POLICY "anon_delete_equipment" ON equipment FOR DELETE
  TO anon, authenticated USING (true);

-- Trigger to update updated_at on UPDATE
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS equipment_updated_at ON equipment;
CREATE TRIGGER equipment_updated_at
  BEFORE UPDATE ON equipment
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS equipment_created_at_idx ON equipment (created_at);
