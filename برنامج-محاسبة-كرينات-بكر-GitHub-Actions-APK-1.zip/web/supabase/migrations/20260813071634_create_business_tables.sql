/*
# Create core business tables: customers, jobs, expenses, payments, job_types, settings, monthly_equipment_days, invoices

1. New Tables
- `customers` — customer records with auto-calculated totals
- `job_types` — user-defined job type options (seeded with defaults)
- `jobs` — income/work transactions linked to customer + equipment
- `expenses` — expense transactions linked to equipment
- `payments` — payment records against jobs (partial/full)
- `invoices` — invoice records with auto-incrementing BK-XXXX number
- `monthly_equipment_days` — per-day record for each equipment in each month
- `settings` — single-row app settings (app name, phone, city, currency, etc.)

2. Relationships
- jobs.customer_id → customers.id (ON DELETE RESTRICT to preserve history)
- jobs.equipment_id → equipment.id (ON DELETE RESTRICT)
- expenses.equipment_id → equipment.id (ON DELETE RESTRICT)
- payments.job_id → jobs.id (ON DELETE CASCADE)
- monthly_equipment_days.equipment_id → equipment.id (ON DELETE CASCADE)
- monthly_equipment_days.customer_id → customers.id (ON DELETE SET NULL, nullable)
- invoices.job_id → jobs.id (ON DELETE SET NULL, nullable)

3. Security
- RLS enabled on all tables.
- All policies: TO anon, authenticated with USING(true)/WITH CHECK(true) — single-tenant no-auth app.

4. Important Notes
- UNIQUE constraint on monthly_equipment_days (equipment_id, date) prevents duplicate day records.
- Settings table uses a singleton row pattern with id=1.
- Invoice numbers auto-generated as BK-XXXX format via a sequence-like approach.
- All financial amounts use numeric(12,2).
*/

-- ===================== CUSTOMERS =====================
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text DEFAULT '',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_customers" ON customers;
CREATE POLICY "anon_select_customers" ON customers FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_customers" ON customers;
CREATE POLICY "anon_insert_customers" ON customers FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_customers" ON customers;
CREATE POLICY "anon_update_customers" ON customers FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_customers" ON customers;
CREATE POLICY "anon_delete_customers" ON customers FOR DELETE TO anon, authenticated USING (true);

-- ===================== JOB TYPES =====================
CREATE TABLE IF NOT EXISTS job_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE job_types ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_job_types" ON job_types;
CREATE POLICY "anon_select_job_types" ON job_types FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_job_types" ON job_types;
CREATE POLICY "anon_insert_job_types" ON job_types FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_job_types" ON job_types;
CREATE POLICY "anon_delete_job_types" ON job_types FOR DELETE TO anon, authenticated USING (true);

-- ===================== JOBS (income/work) =====================
CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL DEFAULT CURRENT_DATE,
  customer_id uuid REFERENCES customers(id) ON DELETE RESTRICT,
  customer_name text NOT NULL DEFAULT '',
  customer_phone text DEFAULT '',
  equipment_id uuid REFERENCES equipment(id) ON DELETE RESTRICT,
  equipment_name text DEFAULT '',
  job_type text NOT NULL DEFAULT 'مشوار',
  location text DEFAULT '',
  description text DEFAULT '',
  work_amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  remaining_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text NOT NULL DEFAULT 'unpaid',
  payment_method text DEFAULT '',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_jobs" ON jobs;
CREATE POLICY "anon_select_jobs" ON jobs FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_jobs" ON jobs;
CREATE POLICY "anon_insert_jobs" ON jobs FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_jobs" ON jobs;
CREATE POLICY "anon_update_jobs" ON jobs FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_jobs" ON jobs;
CREATE POLICY "anon_delete_jobs" ON jobs FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS jobs_date_idx ON jobs (date);
CREATE INDEX IF NOT EXISTS jobs_customer_idx ON jobs (customer_id);
CREATE INDEX IF NOT EXISTS jobs_equipment_idx ON jobs (equipment_id);

-- ===================== EXPENSES =====================
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL DEFAULT CURRENT_DATE,
  equipment_id uuid REFERENCES equipment(id) ON DELETE RESTRICT,
  equipment_name text DEFAULT '',
  expense_type text NOT NULL DEFAULT 'مصروف آخر',
  amount numeric(12,2) NOT NULL DEFAULT 0,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_expenses" ON expenses;
CREATE POLICY "anon_select_expenses" ON expenses FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_expenses" ON expenses;
CREATE POLICY "anon_insert_expenses" ON expenses FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_expenses" ON expenses;
CREATE POLICY "anon_update_expenses" ON expenses FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_expenses" ON expenses;
CREATE POLICY "anon_delete_expenses" ON expenses FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS expenses_date_idx ON expenses (date);
CREATE INDEX IF NOT EXISTS expenses_equipment_idx ON expenses (equipment_id);

-- ===================== PAYMENTS =====================
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE RESTRICT,
  amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_method text DEFAULT '',
  date date NOT NULL DEFAULT CURRENT_DATE,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_payments" ON payments;
CREATE POLICY "anon_select_payments" ON payments FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_payments" ON payments;
CREATE POLICY "anon_insert_payments" ON payments FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_payments" ON payments;
CREATE POLICY "anon_delete_payments" ON payments FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS payments_job_idx ON payments (job_id);
CREATE INDEX IF NOT EXISTS payments_customer_idx ON payments (customer_id);

-- ===================== INVOICES =====================
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text NOT NULL,
  job_id uuid REFERENCES jobs(id) ON DELETE SET NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  customer_name text NOT NULL DEFAULT '',
  customer_phone text DEFAULT '',
  equipment_name text DEFAULT '',
  job_type text DEFAULT '',
  location text DEFAULT '',
  description text DEFAULT '',
  work_amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  remaining_amount numeric(12,2) NOT NULL DEFAULT 0,
  payment_status text DEFAULT '',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_invoices" ON invoices;
CREATE POLICY "anon_select_invoices" ON invoices FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_invoices" ON invoices;
CREATE POLICY "anon_insert_invoices" ON invoices FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_invoices" ON invoices;
CREATE POLICY "anon_delete_invoices" ON invoices FOR DELETE TO anon, authenticated USING (true);
CREATE UNIQUE INDEX IF NOT EXISTS invoices_number_idx ON invoices (invoice_number);

-- ===================== MONTHLY EQUIPMENT DAYS =====================
CREATE TABLE IF NOT EXISTS monthly_equipment_days (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  equipment_id uuid NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
  date date NOT NULL,
  day_status text NOT NULL DEFAULT 'idle',
  job_type text DEFAULT '',
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  customer_name text DEFAULT '',
  location text DEFAULT '',
  work_amount numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  remaining_amount numeric(12,2) NOT NULL DEFAULT 0,
  expense_amount numeric(12,2) NOT NULL DEFAULT 0,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (equipment_id, date)
);
ALTER TABLE monthly_equipment_days ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_monthly_days" ON monthly_equipment_days;
CREATE POLICY "anon_select_monthly_days" ON monthly_equipment_days FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_monthly_days" ON monthly_equipment_days;
CREATE POLICY "anon_insert_monthly_days" ON monthly_equipment_days FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_monthly_days" ON monthly_equipment_days;
CREATE POLICY "anon_update_monthly_days" ON monthly_equipment_days FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_monthly_days" ON monthly_equipment_days;
CREATE POLICY "anon_delete_monthly_days" ON monthly_equipment_days FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS monthly_days_equipment_idx ON monthly_equipment_days (equipment_id);
CREATE INDEX IF NOT EXISTS monthly_days_date_idx ON monthly_equipment_days (date);

-- ===================== SETTINGS =====================
CREATE TABLE IF NOT EXISTS settings (
  id int PRIMARY KEY DEFAULT 1,
  app_name text NOT NULL DEFAULT 'برنامج محاسبة كرينات بكر',
  business_name text NOT NULL DEFAULT 'إدارة محاسبية متكاملة',
  phone text NOT NULL DEFAULT '0558995962',
  city text NOT NULL DEFAULT 'خميس مشيط',
  currency text NOT NULL DEFAULT 'ريال سعودي',
  logo_data text DEFAULT '',
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT singleton_row CHECK (id = 1)
);
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_settings" ON settings;
CREATE POLICY "anon_select_settings" ON settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_settings" ON settings;
CREATE POLICY "anon_insert_settings" ON settings FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_settings" ON settings;
CREATE POLICY "anon_update_settings" ON settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- Seed default settings row
INSERT INTO settings (id) VALUES (1) ON CONFLICT DO NOTHING;

-- Seed default job types
INSERT INTO job_types (name) VALUES
  ('مشوار'), ('ساعة'), ('يومية'), ('أسبوع'), ('شهري'), ('عقد'), ('عمل خاص')
ON CONFLICT DO NOTHING;

-- updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS customers_updated_at ON customers;
CREATE TRIGGER customers_updated_at BEFORE UPDATE ON customers FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS jobs_updated_at ON jobs;
CREATE TRIGGER jobs_updated_at BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS expenses_updated_at ON expenses;
CREATE TRIGGER expenses_updated_at BEFORE UPDATE ON expenses FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS monthly_days_updated_at ON monthly_equipment_days;
CREATE TRIGGER monthly_days_updated_at BEFORE UPDATE ON monthly_equipment_days FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS settings_updated_at ON settings;
CREATE TRIGGER settings_updated_at BEFORE UPDATE ON settings FOR EACH ROW EXECUTE FUNCTION update_updated_at();
