import { CalendarClock, ChevronLeft, TrendingUp, TrendingDown, Wallet, Truck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect, useCallback } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Card } from '@/components/ui/Card';
import { StatCard } from '@/components/dashboard/StatCard';
import { type Equipment, fetchEquipment } from '@/lib/equipment';
import { formatSAR } from '@/lib/format';

export function MonthlyPage() {
  const navigate = useNavigate();
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const list = await fetchEquipment();
      setEquipment(list);
    } catch {
      setEquipment([]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const totalIncome = 0;
  const totalExpenses = 0;
  const totalProfit = totalIncome - totalExpenses;

  return (
    <AppLayout showHeader={false} showBottomNav={false}>
      <div className="pt-4">
        <PageHeader
          title="الحساب الشهري"
          subtitle="الحسابات الشهرية للمعدات"
          icon={CalendarClock}
          onBack={() => navigate('/')}
        />

        {/* Summary */}
        <section className="grid grid-cols-3 gap-2.5 mb-4">
          <StatCard label="إجمالي الدخل" amount={formatSAR(totalIncome)} icon={TrendingUp} tone="income" delay={0} />
          <StatCard label="المصروفات" amount={formatSAR(totalExpenses)} icon={TrendingDown} tone="expense" delay={60} />
          <StatCard label="الربح" amount={formatSAR(totalProfit)} icon={Wallet} tone="profit" delay={120} />
        </section>

        {/* Per-equipment monthly cards */}
        <h3 className="text-sm font-bold text-white font-display mb-3">حسابات المعدات</h3>
        {loading ? (
          <Card className="p-8 text-center">
            <p className="text-sm text-slate-400">جاري التحميل...</p>
          </Card>
        ) : equipment.length === 0 ? (
          <Card className="p-6 flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mb-3">
              <Truck className="w-7 h-7 text-slate-600" strokeWidth={1.5} />
            </div>
            <p className="text-sm text-slate-400">لا توجد معدات بعد</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {equipment.map((eq, i) => (
              <Card
                key={eq.id}
                onClick={() => navigate(`/monthly/${eq.id}`)}
                className="p-4 animate-slide-up"
              >
                <div className="flex items-center gap-3" style={{ animationDelay: `${i * 60}ms` }}>
                  <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 bg-ink-900/60 flex items-center justify-center">
                    {eq.image ? (
                      <img
                        src={eq.image}
                        alt={eq.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Truck className="w-6 h-6 text-slate-600" strokeWidth={1.5} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Truck className="w-4 h-4 text-gold-400 flex-shrink-0" />
                      <p className="text-sm font-semibold text-slate-100 truncate">{eq.name}</p>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      0 شهر
                    </p>
                  </div>
                  <div className="text-left flex-shrink-0">
                    <p className="text-sm font-bold text-profit tabular-nums">{formatSAR(0)}</p>
                    <p className="text-[11px] text-slate-500">صافي الربح</p>
                  </div>
                  <ChevronLeft className="w-5 h-5 text-slate-600 flex-shrink-0" />
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
