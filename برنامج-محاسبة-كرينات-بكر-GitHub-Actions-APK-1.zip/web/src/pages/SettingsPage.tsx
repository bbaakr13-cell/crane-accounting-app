import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings as SettingsIcon, Save, Download, Upload, Phone, MapPin, Building2, CreditCard, Image } from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Card } from '@/components/ui/Card';
import { CraneLogo } from '@/components/CraneLogo';
import { fetchSettings, saveSettings, type AppSettings } from '@/lib/settings';
import { supabase } from '@/lib/supabase';

export function SettingsPage() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const s = await fetchSettings();
      setSettings(s);
    } catch {
      setSettings({
        appName: 'برنامج محاسبة كرينات بكر',
        businessName: 'إدارة محاسبية متكاملة',
        phone: '0558995962',
        city: 'خميس مشيط',
        currency: 'ريال سعودي',
        logo: '',
      });
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function handleLogoSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setSettings(prev => prev ? { ...prev, logo: reader.result as string } : prev);
    };
    reader.readAsDataURL(file);
  }

  async function handleSave() {
    if (!settings) return;
    setSaving(true);
    setError('');
    try {
      await saveSettings(settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch {
      setError('حدث خطأ أثناء الحفظ');
    }
    setSaving(false);
  }

  async function handleExport() {
    try {
      const tables = ['equipment', 'customers', 'jobs', 'expenses', 'payments', 'invoices', 'monthly_equipment_days', 'settings', 'job_types'];
      const backup: Record<string, any> = {};
      for (const t of tables) {
        const { data } = await supabase.from(t).select('*');
        backup[t] = data ?? [];
      }
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      setError('فشل تصدير النسخة الاحتياطية');
    }
  }

  async function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!confirm('سيتم استبدال البيانات الحالية. هل أنت متأكد؟')) return;
    try {
      const text = await file.text();
      const backup = JSON.parse(text);
      for (const [table, rows] of Object.entries(backup)) {
        if (Array.isArray(rows) && rows.length > 0) {
          await supabase.from(table).delete().neq('id', '00000000-0000-0000-0000-000000000000');
          await supabase.from(table).insert(rows);
        }
      }
      await load();
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch {
      setError('فشل استعادة النسخة الاحتياطية');
    }
  }

  if (!settings) {
    return (
      <AppLayout showHeader={false} showBottomNav={false}>
        <div className="pt-4">
          <PageHeader title="الإعدادات" icon={SettingsIcon} onBack={() => navigate('/')} />
          <Card className="p-8 text-center"><p className="text-sm text-slate-400">جاري التحميل...</p></Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout showHeader={false} showBottomNav={false}>
      <div className="pt-4">
        <PageHeader title="الإعدادات" icon={SettingsIcon} onBack={() => navigate('/')} />

        {/* Logo preview */}
        <Card className="p-6 mb-4 flex flex-col items-center">
          <div className="w-20 h-20 rounded-2xl bg-ink-900/60 flex items-center justify-center mb-3 overflow-hidden">
            {settings.logo ? (
              <img src={settings.logo} alt="شعار" className="w-full h-full object-contain" />
            ) : (
              <CraneLogo size={56} />
            )}
          </div>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-200 text-sm font-medium active:scale-95 transition-transform"
          >
            <Image className="w-4 h-4" />
            تغيير الشعار
          </button>
          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleLogoSelect} />
        </Card>

        {/* Settings form */}
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-slate-400 mb-1.5 block">اسم البرنامج</label>
            <div className="relative">
              <Building2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                value={settings.appName}
                onChange={(e) => setSettings({ ...settings, appName: e.target.value })}
                className="w-full bg-ink-850/80 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-sm text-slate-100 focus:outline-none focus:border-gold-500/40 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400 mb-1.5 block">اسم النشاط</label>
            <input
              value={settings.businessName}
              onChange={(e) => setSettings({ ...settings, businessName: e.target.value })}
              className="w-full bg-ink-850/80 border border-white/10 rounded-xl py-3 px-4 text-sm text-slate-100 focus:outline-none focus:border-gold-500/40 transition-colors"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400 mb-1.5 block">رقم الجوال</label>
            <div className="relative">
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                value={settings.phone}
                onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                inputMode="tel"
                className="w-full bg-ink-850/80 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-sm text-slate-100 focus:outline-none focus:border-gold-500/40 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400 mb-1.5 block">المدينة</label>
            <div className="relative">
              <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                value={settings.city}
                onChange={(e) => setSettings({ ...settings, city: e.target.value })}
                className="w-full bg-ink-850/80 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-sm text-slate-100 focus:outline-none focus:border-gold-500/40 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-400 mb-1.5 block">العملة</label>
            <div className="relative">
              <CreditCard className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                value={settings.currency}
                onChange={(e) => setSettings({ ...settings, currency: e.target.value })}
                className="w-full bg-ink-850/80 border border-white/10 rounded-xl py-3 pr-10 pl-4 text-sm text-slate-100 focus:outline-none focus:border-gold-500/40 transition-colors"
              />
            </div>
          </div>

          {error && <p className="text-sm text-expense text-center">{error}</p>}
          {saved && <p className="text-sm text-income text-center">تم الحفظ بنجاح</p>}

          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full py-3.5 rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 text-ink-950 font-bold text-sm shadow-glow-gold active:scale-95 transition-transform flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Save className="w-5 h-5" strokeWidth={2.5} />
            {saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
          </button>
        </div>

        {/* Backup & Restore */}
        <div className="mt-6">
          <h3 className="text-sm font-bold text-white font-display mb-3">النسخ الاحتياطي</h3>
          <div className="flex gap-3">
            <button
              onClick={handleExport}
              className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-slate-200 font-medium text-sm active:scale-95 transition-transform flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              تصدير نسخة
            </button>
            <label className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-slate-200 font-medium text-sm active:scale-95 transition-transform flex items-center justify-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4" />
              استعادة نسخة
              <input type="file" accept=".json" className="hidden" onChange={handleImport} />
            </label>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
