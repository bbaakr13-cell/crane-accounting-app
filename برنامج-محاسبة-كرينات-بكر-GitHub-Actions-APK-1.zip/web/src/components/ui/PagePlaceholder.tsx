import { type ReactNode } from 'react';
import { type LucideIcon } from 'lucide-react';
import { Card } from '@/components/ui/Card';

interface PagePlaceholderProps {
  title: string;
  description?: string;
  icon: LucideIcon;
  children?: ReactNode;
}

export function PagePlaceholder({ title, description, icon: Icon, children }: PagePlaceholderProps) {
  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-11 h-11 rounded-xl bg-gold-500/10 flex items-center justify-center">
          <Icon className="w-6 h-6 text-gold-400" strokeWidth={2} />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white font-display">{title}</h2>
          {description && <p className="text-xs text-slate-400 mt-0.5">{description}</p>}
        </div>
      </div>
      <Card className="p-8 flex flex-col items-center justify-center text-center min-h-[40vh]">
        <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-4">
          <Icon className="w-8 h-8 text-slate-500" strokeWidth={1.5} />
        </div>
        <p className="text-sm text-slate-400 max-w-xs">
          هذه الصفحة قيد التطوير. سيتم إضافة المحتوى قريباً.
        </p>
        {children}
      </Card>
    </div>
  );
}
