import { type ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}

export function Card({ children, className = '', onClick }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={`rounded-2xl bg-ink-850/80 border border-white/5 shadow-card backdrop-blur-sm ${className} ${
        onClick ? 'cursor-pointer active:scale-[0.98] transition-transform duration-150' : ''
      }`}
    >
      {children}
    </div>
  );
}
