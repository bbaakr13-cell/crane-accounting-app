import { Truck, Wrench, TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { type Equipment, statusLabels, statusStyles } from '@/lib/equipment';
import { formatSAR } from '@/lib/format';
import { fetchEquipmentStats, type EquipmentStats } from '@/lib/transactions';
import { useState, useEffect } from 'react';

interface EquipmentCardProps {
  equipment: Equipment;
  onClick: () => void;
  onMonthlyClick?: () => void;
  delay?: number;
}

export function EquipmentCard({ equipment, onClick, onMonthlyClick, delay = 0 }: EquipmentCardProps) {
  const styles = statusStyles[equipment.status];
  const [stats, setStats] = useState<EquipmentStats>({ totalJobValue: 0, totalPaid: 0, totalRemaining: 0, totalExpenses: 0, netProfit: 0, jobsCount: 0 });

  useEffect(() => {
    fetchEquipmentStats(equipment.id).then(setStats).catch(() => {});
  }, [equipment.id]);

  return (
    <Card onClick={onClick} className="overflow-hidden animate-slide-up">
      <div className="relative h-[200px] overflow-hidden" style={{ animationDelay: `${delay}ms` }}>
        {equipment.image ? (
          <img src={equipment.image} alt={equipment.name} className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <div className="w-full h-full bg-ink-900/60 flex items-center justify-center">
            <Truck className="w-12 h-12 text-slate-600" strokeWidth={1.5} />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ink-850 via-ink-850/40 to-transparent" />
        <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-ink-950/70 backdrop-blur-sm">
          <span className={`w-1.5 h-1.5 rounded-full ${styles.dot}`} />
          <span className={`text-[11px] font-medium ${styles.text}`}>{statusLabels[equipment.status]}</span>
        </div>
        <div className="absolute bottom-2 right-3 left-3 flex items-end justify-between">
          <div>
            <h3 className="text-base font-bold text-white font-display">{equipment.name}</h3>
            {equipment.capacity && (
              <p className="text-xs text-slate-300 mt-0.5 flex items-center gap-1">
                <Wrench className="w-3 h-3" /> {equipment.capacity} طن
              </p>
            )}
          </div>
          <div className="w-9 h-9 rounded-xl bg-ink-950/70 backdrop-blur-sm flex items-center justify-center">
            <Truck className="w-5 h-5 text-gold-400" strokeWidth={2} />
          </div>
        </div>
      </div>

      <div className="p-3.5">
        <div className="grid grid-cols-3 gap-2 text-center mb-3">
          <div className="rounded-xl bg-income/5 py-2 px-1">
            <p className="text-[10px] text-slate-500 mb-0.5">الدخل</p>
            <p className="text-xs font-bold text-income tabular-nums">{formatSAR(stats.totalJobValue)}</p>
          </div>
          <div className="rounded-xl bg-expense/5 py-2 px-1">
            <p className="text-[10px] text-slate-500 mb-0.5">المصروفات</p>
            <p className="text-xs font-bold text-expense tabular-nums">{formatSAR(stats.totalExpenses)}</p>
          </div>
          <div className="rounded-xl bg-profit/5 py-2 px-1">
            <p className="text-[10px] text-slate-500 mb-0.5">الربح</p>
            <p className="text-xs font-bold text-profit tabular-nums">{formatSAR(stats.netProfit)}</p>
          </div>
        </div>

        <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
          <span>{stats.jobsCount} عمل</span>
        </div>

        <div className="flex gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); onClick(); }}
            className="flex-1 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-200 text-xs font-medium active:scale-95 transition-transform"
          >
            التفاصيل
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); onMonthlyClick?.(); }}
            className="flex-1 py-2 rounded-xl bg-receivable/10 border border-receivable/20 text-receivable text-xs font-medium active:scale-95 transition-transform"
          >
            الحساب الشهري
          </button>
        </div>
      </div>
    </Card>
  );
}
