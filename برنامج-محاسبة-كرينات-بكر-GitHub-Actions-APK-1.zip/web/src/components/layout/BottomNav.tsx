import { NavLink } from 'react-router-dom';
import { Home, Receipt, Plus, Users, FileBarChart } from 'lucide-react';

const navItems = [
  { to: '/', label: 'الرئيسية', icon: Home },
  { to: '/transactions', label: 'الحركات', icon: Receipt },
  { to: '/add', label: 'إضافة', icon: Plus, center: true },
  { to: '/customers', label: 'العملاء', icon: Users },
  { to: '/reports', label: 'التقارير', icon: FileBarChart },
];

export function BottomNav() {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 pointer-events-none">
      <div className="mx-auto max-w-md px-3 pb-2 safe-bottom pointer-events-auto">
        <div className="rounded-2xl bg-ink-850/95 backdrop-blur-lg border border-white/10 shadow-card">
          <div className="flex items-end justify-around h-16">
            {navItems.map((item) => {
              const Icon = item.icon;
              if (item.center) {
                return (
                  <NavLink key={item.to} to={item.to} className="flex flex-col items-center -mt-5">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-glow-gold active:scale-90 transition-transform">
                      <Icon className="w-7 h-7 text-ink-950" strokeWidth={2.5} />
                    </div>
                    <span className="text-[10px] font-medium text-gold-300 mt-0.5">{item.label}</span>
                  </NavLink>
                );
              }
              return (
                <NavLink key={item.to} to={item.to} className="flex flex-col items-center justify-center gap-1 flex-1 h-full">
                  {({ isActive }) => (
                    <>
                      <Icon
                        className={`w-5 h-5 transition-colors ${isActive ? 'text-gold-400' : 'text-slate-500'}`}
                        strokeWidth={isActive ? 2.4 : 2}
                      />
                      <span
                        className={`text-[10px] font-medium transition-colors ${
                          isActive ? 'text-gold-300' : 'text-slate-500'
                        }`}
                      >
                        {item.label}
                      </span>
                    </>
                  )}
                </NavLink>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
