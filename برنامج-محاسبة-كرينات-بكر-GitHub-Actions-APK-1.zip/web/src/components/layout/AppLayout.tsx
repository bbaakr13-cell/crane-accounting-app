import { type ReactNode } from 'react';
import { Header } from '@/components/layout/Header';
import { BottomNav } from '@/components/layout/BottomNav';

interface AppLayoutProps {
  children: ReactNode;
  showHeader?: boolean;
  showBottomNav?: boolean;
}

export function AppLayout({ children, showHeader = true, showBottomNav = true }: AppLayoutProps) {
  return (
    <div className="min-h-screen bg-ink-950 max-w-md mx-auto relative">
      {showHeader && <Header />}
      <main className={`px-4 ${showHeader ? 'pt-2' : 'pt-4'} ${showBottomNav ? 'pb-28' : 'pb-6'}`}>
        <div className="route-enter">{children}</div>
      </main>
      {showBottomNav && <BottomNav />}
    </div>
  );
}
