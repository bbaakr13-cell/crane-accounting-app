import { MapPin, Settings, Bell, Menu, Truck } from 'lucide-react';

const HERO_IMAGE =
  'https://images.pexels.com/photos/30278762/pexels-photo-30278762.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

interface HeaderProps {
  onMenuClick?: () => void;
}

export function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="relative overflow-hidden">
      {/* Hero background */}
      <div className="absolute inset-0 h-56">
        <img
          src={HERO_IMAGE}
          alt="كرين بكر"
          className="w-full h-full object-cover opacity-30"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/70 via-ink-900/85 to-ink-950" />
        <div className="absolute inset-0 bg-gradient-to-l from-gold-500/10 via-transparent to-transparent" />
      </div>

      {/* Top bar */}
      <div className="relative safe-top pt-3 px-4">
        <div className="flex items-center justify-between">
          <button
            onClick={onMenuClick}
            className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center active:scale-95 transition-transform"
            aria-label="القائمة"
          >
            <Menu className="w-5 h-5 text-slate-300" />
          </button>

          <div className="flex items-center gap-2">
            <button
              className="relative w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center active:scale-95 transition-transform"
              aria-label="الإشعارات"
            >
              <Bell className="w-5 h-5 text-slate-300" />
              <span className="absolute top-2 left-2 w-2 h-2 rounded-full bg-gold-400 ring-2 ring-ink-900" />
            </button>
            <button
              className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center active:scale-95 transition-transform"
              aria-label="الإعدادات"
            >
              <Settings className="w-5 h-5 text-slate-300" />
            </button>
          </div>
        </div>
      </div>

      {/* Logo + title */}
      <div className="relative px-4 pt-6 pb-10">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-glow-gold flex-shrink-0">
            <Truck className="w-7 h-7 text-ink-950" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white font-display leading-tight">
              محاسبة كرينات بكر
            </h1>
            <p className="text-xs text-gold-300/90 font-medium">إدارة محاسبية متكاملة</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <MapPin className="w-3.5 h-3.5 text-gold-400" />
          <span>خميس مشيط - السعودية</span>
        </div>
      </div>
    </header>
  );
}
