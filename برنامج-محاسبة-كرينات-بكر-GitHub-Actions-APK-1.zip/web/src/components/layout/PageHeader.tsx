import { type LucideIcon } from 'lucide-react';
import { ChevronRight } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  icon: LucideIcon;
  onBack: () => void;
  action?: React.ReactNode;
}

export function PageHeader({ title, subtitle, icon: Icon, onBack, action }: PageHeaderProps) {
  return (
    <div className="flex items-center justify-between gap-3 mb-6 animate-fade-in">
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center active:scale-95 transition-transform flex-shrink-0"
          aria-label="رجوع"
        >
          <ChevronRight className="w-5 h-5 text-slate-300" />
        </button>
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gold-500/10 flex items-center justify-center flex-shrink-0">
            <Icon className="w-5 h-5 text-gold-400" strokeWidth={2} />
          </div>
          <div className="min-w-0">
            <h2 className="text-lg font-bold text-white font-display leading-tight truncate">{title}</h2>
            {subtitle && <p className="text-xs text-slate-400 mt-0.5 truncate">{subtitle}</p>}
          </div>
        </div>
      </div>
      {action}
    </div>
  );
}
