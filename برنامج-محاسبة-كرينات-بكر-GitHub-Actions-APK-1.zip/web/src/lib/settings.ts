import { supabase } from '@/lib/supabase';

export interface AppSettings {
  appName: string;
  businessName: string;
  phone: string;
  city: string;
  currency: string;
  logo: string;
}

const DEFAULT_SETTINGS: AppSettings = {
  appName: 'برنامج محاسبة كرينات بكر',
  businessName: 'إدارة محاسبية متكاملة',
  phone: '0558995962',
  city: 'خميس مشيط',
  currency: 'ريال سعودي',
  logo: '',
};

export async function fetchSettings(): Promise<AppSettings> {
  const { data, error } = await supabase.from('settings').select('*').eq('id', 1).maybeSingle();
  if (error || !data) return DEFAULT_SETTINGS;
  return {
    appName: data.app_name ?? DEFAULT_SETTINGS.appName,
    businessName: data.business_name ?? DEFAULT_SETTINGS.businessName,
    phone: data.phone ?? DEFAULT_SETTINGS.phone,
    city: data.city ?? DEFAULT_SETTINGS.city,
    currency: data.currency ?? DEFAULT_SETTINGS.currency,
    logo: data.logo_data ?? '',
  };
}

export async function saveSettings(s: AppSettings): Promise<void> {
  const { error } = await supabase.from('settings').upsert({
    id: 1,
    app_name: s.appName,
    business_name: s.businessName,
    phone: s.phone,
    city: s.city,
    currency: s.currency,
    logo_data: s.logo,
  });
  if (error) throw error;
}

export { DEFAULT_SETTINGS };
