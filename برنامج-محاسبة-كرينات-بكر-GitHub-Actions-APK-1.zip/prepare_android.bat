@echo off
cd /d "%~dp0web"
call npm install
if errorlevel 1 exit /b 1
call npm run android:prepare
if errorlevel 1 exit /b 1
echo.
echo تم تجهيز ملفات التطبيق داخل Android.
echo افتح مجلد android في Android Studio ثم Build APK.
pause
