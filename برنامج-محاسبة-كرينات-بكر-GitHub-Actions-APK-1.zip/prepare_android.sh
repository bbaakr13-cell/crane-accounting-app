#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/web"
npm install
npm run android:prepare
echo "تم تجهيز ملفات التطبيق داخل Android."
echo "افتح مجلد android في Android Studio ثم Build APK."
