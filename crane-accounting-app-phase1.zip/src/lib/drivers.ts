export type DriverDayStatus='worked'|'absent'|'idle'|'overtime';
export interface Driver {id:string;name:string;phone:string;equipment:string;salary:number;year:number;month:number;days:Record<string,DriverDayStatus>;withdrawals:{id:string;date:string;amount:number;note:string}[];overtimeValue:number;notes:string;}
const KEY='bakr_drivers_v1';
export function getDrivers():Driver[]{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch{return []}}
export function saveDrivers(v:Driver[]){localStorage.setItem(KEY,JSON.stringify(v))}
export function addDriver(v:Omit<Driver,'id'>){const all=getDrivers();all.unshift({...v,id:crypto.randomUUID()});saveDrivers(all)}
export function updateDriver(v:Driver){saveDrivers(getDrivers().map(x=>x.id===v.id?v:x))}
export function deleteDriver(id:string){saveDrivers(getDrivers().filter(x=>x.id!==id))}
