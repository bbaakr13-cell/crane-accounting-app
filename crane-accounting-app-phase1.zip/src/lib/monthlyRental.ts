export type RentalDayStatus = 'worked' | 'absent' | 'idle';
export interface MonthlyRental {
  id:string; customerName:string; phone:string; equipmentName:string; monthlyPrice:number; paid:number; year:number; month:number;
  days:Record<string,RentalDayStatus>; notes:string; createdAt:string;
}
const KEY='bakr_monthly_rentals_v1';
export function getRentals():MonthlyRental[]{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch{return []}}
export function saveRentals(v:MonthlyRental[]){localStorage.setItem(KEY,JSON.stringify(v))}
export function addRental(v:Omit<MonthlyRental,'id'|'createdAt'>){const all=getRentals();all.unshift({...v,id:crypto.randomUUID(),createdAt:new Date().toISOString()});saveRentals(all)}
export function updateRental(v:MonthlyRental){saveRentals(getRentals().map(x=>x.id===v.id?v:x))}
export function deleteRental(id:string){saveRentals(getRentals().filter(x=>x.id!==id))}
